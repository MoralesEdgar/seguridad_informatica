-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1:33065
-- Tiempo de generación: 12-10-2017 a las 13:01:33
-- Versión del servidor: 10.1.26-MariaDB
-- Versión de PHP: 7.1.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `db_seguridad`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `susti`
--

CREATE TABLE `susti` (
  `id` int(30) UNSIGNED NOT NULL,
  `mensaje` varchar(30) NOT NULL,
  `llaveA` varchar(32) NOT NULL,
  `llaveB` varchar(32) NOT NULL,
  `cifrado` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `susti`
--

INSERT INTO `susti` (`id`, `mensaje`, `llaveA`, `llaveB`, `cifrado`) VALUES
(54, '', '™>,(Kù”mGì¡êýô', 'NùI#×ÀàaÔM)¸¨', ''),
(55, '', '™>,(Kù”mGì¡êýô', 'NùI#×ÀàaÔM)¸¨', ''),
(56, '', '™>,(Kù”mGì¡êýô', 'NùI#×ÀàaÔM)¸¨', ''),
(57, '', '™>,(Kù”mGì¡êýô', 'NùI#×ÀàaÔM)¸¨', ''),
(58, 'hola', 'h/RÄŽÎ½ã2œI¼@Ï', '¦di¥&Ïæ\nI`‚Õø\'„', 'nwhe'),
(59, 'hola', 'h/RÄŽÎ½ã2œI¼@Ï', '¦di¥&Ïæ\nI`‚Õø\'„', 'nwhe'),
(60, 'jajaja', 'W3˜úsÇ.b’Àb:\"', 'ŠË\ngTgP•°¿ãÌÜZ', 'pfpfpf'),
(61, '', 'W3˜úsÇ.b’Àb:\"', 'ŠË\ngTgP•°¿ãÌÜZ', ''),
(62, 'hola', 'W3˜úsÇ.b’Àb:\"', 'ŠË\ngTgP•°¿ãÌÜZ', 'hjxf'),
(63, 'hola', 'W3˜úsÇ.b’Àb:\"', 'ÍMJGÚ¨\\è`úþÁÅü', 'cesa'),
(64, 'crayola', 'h/RÄŽÎ½ã2œI¼@Ï', '±“ÿn‘(Àÿšò›1óÙ@ç', 'nkdtvgd'),
(65, 'crayola', 'h/RÄŽÎ½ã2œI¼@Ï', '±“ÿn‘(Àÿšò›1óÙ@ç', 'khaqsda'),
(66, 'crayola', 'h/RÄŽÎ½ã2œI¼@Ï', '±“ÿn‘(Àÿšò›1óÙ@ç', 'khaqsda'),
(67, 'crayola', 'h/RÄŽÎ½ã2œI¼@Ï', '±“ÿn‘(Àÿšò›1óÙ@ç', 'khaqsda'),
(68, 'crayola', 'h/RÄŽÎ½ã2œI¼@Ï', '±“ÿn‘(Àÿšò›1óÙ@ç', ''),
(69, 'crayola', 'h/RÄŽÎ½ã2œI¼@Ï', '±“ÿn‘(Àÿšò›1óÙ@ç', 'khaqsda'),
(70, 'crayola', 'h/RÄŽÎ½ã2œI¼@Ï', '±“ÿn‘(Àÿšò›1óÙ@ç', 'khaqsda'),
(71, 'crayola', 'h/RÄŽÎ½ã2œI¼@Ï', '±“ÿn‘(Àÿšò›1óÙ@ç', 'nkdtvgd'),
(72, 'crayola', 'h/RÄŽÎ½ã2œI¼@Ï', '±“ÿn‘(Àÿšò›1óÙ@ç', 'nkdtvgd'),
(73, 'crayola', 'h/RÄŽÎ½ã2œI¼@Ï', '±“ÿn‘(Àÿšò›1óÙ@ç', 'nkdtvgd'),
(74, 'crayola', 'h/RÄŽÎ½ã2œI¼@Ï', '±“ÿn‘(Àÿšò›1óÙ@ç', 'nkdtvgd'),
(75, 'crayola', 'h/RÄŽÎ½ã2œI¼@Ï', '±“ÿn‘(Àÿšò›1óÙ@ç', 'nkdtvgd'),
(76, 'crayola', 'h/RÄŽÎ½ã2œI¼@Ï', '±“ÿn‘(Àÿšò›1óÙ@ç', 'iiiiiii'),
(77, 'crayola', 'h/RÄŽÎ½ã2œI¼@Ï', '±“ÿn‘(Àÿšò›1óÙ@ç', 'iiiiiii'),
(78, 'crayola', 'h/RÄŽÎ½ã2œI¼@Ï', '±“ÿn‘(Àÿšò›1óÙ@ç', 'nkdtvgd'),
(79, 'crayola', 'h/RÄŽÎ½ã2œI¼@Ï', '±“ÿn‘(Àÿšò›1óÙ@ç', 'nkdtvgd');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `transposicion`
--

CREATE TABLE `transposicion` (
  `id` int(11) UNSIGNED NOT NULL,
  `mensajetra` varchar(50) NOT NULL,
  `columna` varchar(32) NOT NULL,
  `orden` varchar(50) NOT NULL,
  `cifrado` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `transposicion`
--

INSERT INTO `transposicion` (`id`, `mensajetra`, `columna`, `orden`, `cifrado`) VALUES
(38, 'hola desde seguridad informatica', 'U1þ=QÌ¬øÞÓòJPp', 'Ÿ³åClö²9ñKÔ‡È', ' lsedna*oesiima_eudoi*hd_r_rcadgaft*'),
(39, 'lo que sea', 'U1þ=QÌ¬øÞÓòJPp', 'XÂ–« òœ¶û3:]¨µß', ' uaqe_so_'),
(40, 'hola desde el tec', '5', 'Ÿ³åClö²9ñKÔ‡È', ' lsl*//oeec//_et*//hd_e//ad_*'),
(41, 'hola desde el tec', 'U1þ=QÌ¬øÞÓòJPp', 'Ÿ³åClö²9ñKÔ‡È', ' lsl*oeec_et*hd_ead_*'),
(42, 'asereje', 'U1þ=QÌ¬øÞÓòJPp', 'öß ñÄð®ù’ÎrQ[‚c', ' e*e*r*seaj'),
(43, 'hola desde el tec', 'U1þ=QÌ¬øÞÓòJPp', 'Ÿ³åClö²9ñKÔ‡È', ' lsl*//oeec//_et*//hd_e//ad_*'),
(44, 'hola desde el tec', 'U1þ=QÌ¬øÞÓòJPp', 'Ÿ³åClö²9ñKÔ‡È', ' lsl*oeec_et*hd_ead_*');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `vige`
--

CREATE TABLE `vige` (
  `id` int(30) UNSIGNED NOT NULL,
  `mensaje` varchar(50) NOT NULL,
  `llave` varchar(30) NOT NULL,
  `cifrado` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `vige`
--

INSERT INTO `vige` (`id`, `mensaje`, `llave`, `cifrado`) VALUES
(5, 'lo que sea', '’² P„%Ja€uTê•E', 'tb vm fj'),
(6, 'hola desde vige', 'œ,‘ŸV5Lm_‹)<LÑÅ', 'wyf aqj or'),
(7, 'hola desde vige', '’² P„%Ja€uTê•E', 'pbq lrxm inm'),
(8, 'jajaja', '’² P„%Ja€uTê•E', 'rnorn'),
(9, 'jajajaja', '’² P„%Ja€uTê•E', 'rnorno'),
(10, 'hola desde vige', '’² P„%Ja€uTê•E', 'pbq lrxm inm'),
(11, 'hola desde vige', '’² P„%Ja€uTê•E', 'pbq lrxm inm'),
(12, 'hola desde vige', '’² P„%Ja€uTê•E', 'pbq lrxm inm'),
(13, 'lo que sea', '’² P„%Ja€uTê•E', 'tb vm fj');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `susti`
--
ALTER TABLE `susti`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `transposicion`
--
ALTER TABLE `transposicion`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `vige`
--
ALTER TABLE `vige`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `susti`
--
ALTER TABLE `susti`
  MODIFY `id` int(30) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=80;
--
-- AUTO_INCREMENT de la tabla `transposicion`
--
ALTER TABLE `transposicion`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;
--
-- AUTO_INCREMENT de la tabla `vige`
--
ALTER TABLE `vige`
  MODIFY `id` int(30) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
